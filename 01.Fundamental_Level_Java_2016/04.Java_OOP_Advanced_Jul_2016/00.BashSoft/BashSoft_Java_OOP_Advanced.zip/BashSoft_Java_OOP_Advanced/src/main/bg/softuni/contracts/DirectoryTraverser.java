package main.bg.softuni.contracts;

public interface DirectoryTraverser {

    void traverseDirectory(int depth);
}
