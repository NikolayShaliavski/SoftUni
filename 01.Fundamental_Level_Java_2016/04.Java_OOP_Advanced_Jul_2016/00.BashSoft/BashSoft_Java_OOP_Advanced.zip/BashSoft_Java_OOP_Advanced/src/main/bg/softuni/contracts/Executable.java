package main.bg.softuni.contracts;

public interface Executable {

    void execute() throws Exception;
}
