package pr04_WorkForce.contracts;

public interface Employee {

    String getName();
    int getWorkHours();
}
