package problem_10.contracts;

/**
 * Created by Nikolay Shalyavski on 24.7.2016 г..
 */
public interface Updatable {

    void updateStats();
}
