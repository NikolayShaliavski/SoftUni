package problem_10.enums;

/**
 * Created by Nikolay Shalyavski on 24.7.2016 г..
 */
public enum GemsEnum {

    RUBY,
    EMERALD,
    AMETHYST;
}
