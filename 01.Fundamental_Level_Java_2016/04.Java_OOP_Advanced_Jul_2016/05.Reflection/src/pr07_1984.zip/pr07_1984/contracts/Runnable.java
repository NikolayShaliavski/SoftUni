package pr07_1984.contracts;

import java.io.IOException;

public interface Runnable {

    void run() throws IOException, IllegalAccessException;
}
