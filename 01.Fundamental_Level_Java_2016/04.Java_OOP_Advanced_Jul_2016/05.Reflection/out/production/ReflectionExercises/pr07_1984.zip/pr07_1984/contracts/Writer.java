package pr07_1984.contracts;

public interface Writer {

    void write(String message);
}
