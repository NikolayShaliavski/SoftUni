package pr07_1984.contracts;

import java.io.IOException;

public interface Reader {

    String read() throws IOException;
}
