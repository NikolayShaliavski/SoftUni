package com.softuni.store.entities.user;

public enum Role {
    ADMIN, USER;
}
