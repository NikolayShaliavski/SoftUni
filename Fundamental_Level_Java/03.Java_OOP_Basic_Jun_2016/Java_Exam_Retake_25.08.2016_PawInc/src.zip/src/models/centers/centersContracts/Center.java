package models.centers.centersContracts;

public interface Center {

    String getName();

    int getWaitingAnimalsCount();
}
