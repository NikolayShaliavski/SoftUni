package core.commands.commandContracts;

public interface Executable {

    void execute();
}
