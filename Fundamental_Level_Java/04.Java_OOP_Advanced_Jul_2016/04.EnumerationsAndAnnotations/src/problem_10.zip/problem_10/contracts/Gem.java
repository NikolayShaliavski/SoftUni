package problem_10.contracts;

/**
 * Created by Nikolay Shalyavski on 23.7.2016 г..
 */
public interface Gem {

    int getStrength();
    int getAgility();
    int getVitality();
}
