package problem_10.contracts;

import java.io.IOException;

/**
 * Created by Nikolay Shalyavski on 24.7.2016 г..
 */
public interface Reader {

    String read() throws IOException;
}
