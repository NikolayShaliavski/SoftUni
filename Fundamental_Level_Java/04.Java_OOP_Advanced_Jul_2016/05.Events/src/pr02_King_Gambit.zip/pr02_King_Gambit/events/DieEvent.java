package pr02_King_Gambit.events;

import java.util.EventObject;

public class DieEvent extends EventObject {

    public DieEvent(Object source) {
        super(source);
    }
}
