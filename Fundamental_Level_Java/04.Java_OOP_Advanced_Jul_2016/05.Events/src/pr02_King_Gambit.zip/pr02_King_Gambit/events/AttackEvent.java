package pr02_King_Gambit.events;

import java.util.EventObject;

public class AttackEvent extends EventObject {

    public AttackEvent(Object source) {
        super(source);
    }
}
