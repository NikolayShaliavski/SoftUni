package pr0304Barracks.core;

import pr0304Barracks.contracts.*;
import pr0304Barracks.contracts.Runnable;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;

public class Engine implements Runnable {

    private static final String COMMAND_PACKAGE = "pr0304Barracks.core.commands.";

    private Repository repository;
    private UnitFactory unitFactory;

    public Engine(Repository repository, UnitFactory unitFactory) {
        this.repository = repository;
        this.unitFactory = unitFactory;
    }

    @Override
    public void run() {
        BufferedReader reader = new BufferedReader(
                new InputStreamReader(System.in));
        while (true) {
            try {
                String input = reader.readLine();
                String[] data = input.split("\\s+");
                String commandName = data[0];
                String result = interpredCommand(data, commandName);
                if (result.equals("fight")) {
                    break;
                }
                System.out.println(result);
            } catch (RuntimeException e) {
                System.out.println(e.getMessage());
            } catch (IOException e) {
                e.printStackTrace();
            } catch (ReflectiveOperationException e) {
                e.printStackTrace();
            }
        }
    }

    // TODO: refactor for problem 4
    private String interpredCommand(String[] data, String commandName) throws ReflectiveOperationException {
        String result;

        commandName = addCapitalLetter(commandName);

        Class<Executable> commandClass =
                (Class<Executable>) Class.forName(COMMAND_PACKAGE + commandName + "Command");
        Constructor commandCtor = commandClass.getConstructor(
                Repository.class, UnitFactory.class, String[].class);
        commandCtor.setAccessible(true);
        Executable command =
                (Executable) commandCtor.newInstance(this.repository, this.unitFactory, data);
        Method execute = command.getClass().getMethod("execute");
        execute.setAccessible(true);
        result = (String) execute.invoke(command);

//		switch (commandName) {
//			case "add":
//				result = this.addUnitCommand(data);
//				break;
//			case "report":
//				result = this.reportCommand(data);
//				break;
//			case "fight":
//				result = this.fightCommand(data);
//				break;
//			default:
//				throw new RuntimeException("Invalid command!");
//		}
        return result;
    }

    private String addCapitalLetter(String commandName) {
        char firstLetter = commandName.charAt(0);
        firstLetter -= 32;
        return firstLetter + commandName.substring(1);
    }

    private String reportCommand(String[] data) {
        String output = this.repository.getStatistics();
        return output;
    }

    private String addUnitCommand(String[] data) throws ReflectiveOperationException {
        String unitType = data[1];
        Unit unitToAdd = this.unitFactory.createUnit(unitType);
        this.repository.addUnit(unitToAdd);
        String output = unitType + " added!";
        return output;
    }

    private String fightCommand(String[] data) {
        return "fight";
    }
}
