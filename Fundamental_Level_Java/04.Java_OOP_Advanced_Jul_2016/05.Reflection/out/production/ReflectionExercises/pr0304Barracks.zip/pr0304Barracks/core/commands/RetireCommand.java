package pr0304Barracks.core.commands;

import pr0304Barracks.contracts.Repository;
import pr0304Barracks.contracts.UnitFactory;

import java.util.NoSuchElementException;

/**
 * Created by Nikolay Shalyavski on 26.7.2016 г..
 */
public class RetireCommand extends Command {

    public RetireCommand(Repository repositoryArg,
                            UnitFactory unitFactoryArg,
                            String[] dataArg) {
        super(repositoryArg, unitFactoryArg, dataArg);
    }

    @Override
    public String execute() throws ReflectiveOperationException {
        String unitType = this.getData()[1];
        try {
            this.getRepository().removeUnit(unitType);
        } catch (NoSuchElementException nsex) {
            return nsex.getMessage();
        }
        return unitType + " retired!";
    }
}
