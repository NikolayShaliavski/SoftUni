package pr0304Barracks.core.commands;

import pr0304Barracks.contracts.Repository;
import pr0304Barracks.contracts.Unit;
import pr0304Barracks.contracts.UnitFactory;

/**
 * Created by Nikolay Shalyavski on 25.7.2016 г..
 */
public class AddCommand extends Command {

    public AddCommand(Repository repositoryArg,
                         UnitFactory unitFactoryArg,
                         String[] dataArg) {
        super(repositoryArg, unitFactoryArg, dataArg);
    }

    @Override
    public String execute() throws ReflectiveOperationException {
        String unitType = super.getData()[1];
        Unit unit = super.getUnitFactory().createUnit(unitType);
        super.getRepository().addUnit(unit);
        String result = unitType + " added!";
        return result;
    }
}
