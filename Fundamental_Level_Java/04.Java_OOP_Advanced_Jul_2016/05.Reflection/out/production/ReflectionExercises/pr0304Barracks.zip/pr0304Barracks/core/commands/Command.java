package pr0304Barracks.core.commands;

import pr0304Barracks.contracts.Executable;
import pr0304Barracks.contracts.Repository;
import pr0304Barracks.contracts.UnitFactory;

/**
 * Created by Nikolay Shalyavski on 25.7.2016 г..
 */
public abstract class Command implements Executable {

    private Repository repository;
    private UnitFactory unitFactory;
    private String[] data;

    protected Command(Repository repositoryArg,
                      UnitFactory unitFactoryArg,
                      String[] dataArg) {
        this.setRepository(repositoryArg);
        this.setUnitFactory(unitFactoryArg);
        this.setData(dataArg);
    }

    protected Repository getRepository() {
        return this.repository;
    }

    private void setRepository(Repository repository) {
        this.repository = repository;
    }

    protected UnitFactory getUnitFactory() {
        return this.unitFactory;
    }

    private void setUnitFactory(UnitFactory unitFactory) {
        this.unitFactory = unitFactory;
    }

    protected String[] getData() {
        return this.data;
    }

    private void setData(String[] data) {
        this.data = data;
    }
}
