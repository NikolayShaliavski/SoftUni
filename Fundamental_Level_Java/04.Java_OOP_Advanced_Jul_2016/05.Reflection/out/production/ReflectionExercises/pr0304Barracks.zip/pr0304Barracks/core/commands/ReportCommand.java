package pr0304Barracks.core.commands;

import pr0304Barracks.contracts.Repository;
import pr0304Barracks.contracts.UnitFactory;

/**
 * Created by Nikolay Shalyavski on 25.7.2016 г..
 */
public class ReportCommand extends Command {

    public ReportCommand(Repository repositoryArg,
                            UnitFactory unitFactoryArg,
                            String[] dataArg) {
        super(repositoryArg, unitFactoryArg, dataArg);
    }

    @Override
    public String execute() throws ReflectiveOperationException {
        String output = super.getRepository().getStatistics();
        return output;
    }
}
