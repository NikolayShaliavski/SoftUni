package bg.softuni.main.enums;

public enum FragmentType {
    Nuclear,
    Cooling
}
