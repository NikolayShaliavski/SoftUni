package bg.softuni.main.enums;

public enum CoreState {
    NORMAL,
    CRITICAL;
}
