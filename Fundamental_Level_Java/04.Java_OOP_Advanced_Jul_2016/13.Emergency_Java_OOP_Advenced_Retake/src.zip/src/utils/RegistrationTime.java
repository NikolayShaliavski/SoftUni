package utils;

public interface RegistrationTime {

    public Integer getHour();

    public Integer getMinutes();

    public Integer getDay();

    public Integer getMonth();

    public Integer getYear();

    public String toString();
}
