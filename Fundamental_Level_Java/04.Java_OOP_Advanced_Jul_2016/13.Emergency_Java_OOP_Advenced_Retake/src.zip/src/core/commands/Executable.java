package core.commands;

public interface Executable {

    String execute();
}
