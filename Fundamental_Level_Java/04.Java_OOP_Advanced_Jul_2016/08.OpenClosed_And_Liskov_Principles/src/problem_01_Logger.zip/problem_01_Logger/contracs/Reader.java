package problem_01_Logger.contracs;

import java.io.IOException;

/**
 * Created by Nikolay Shalyavski on 30.7.2016 г..
 */
public interface Reader {

    String read() throws IOException;
}
