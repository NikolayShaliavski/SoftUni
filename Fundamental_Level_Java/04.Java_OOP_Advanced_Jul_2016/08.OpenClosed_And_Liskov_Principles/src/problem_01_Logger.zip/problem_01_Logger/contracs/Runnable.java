package problem_01_Logger.contracs;

import java.io.IOException;

public interface Runnable {

    void run() throws IOException, ReflectiveOperationException;
}
