package problem_01_Logger.contracs;

/**
 * Created by Nikolay Shalyavski on 30.7.2016 г..
 */
public interface Writer {

    void write(String text);
}
