package problem_01_Logger.contracs;

/**
 * Created by Nikolay Shalyavski on 29.7.2016 г..
 */
public interface File extends Writer {

    int getSize();
}
