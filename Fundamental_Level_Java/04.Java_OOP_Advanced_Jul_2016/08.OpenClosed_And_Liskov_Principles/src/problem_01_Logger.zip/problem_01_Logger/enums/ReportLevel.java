package problem_01_Logger.enums;

/**
 * Created by Nikolay Shalyavski on 29.7.2016 г..
 */
public enum ReportLevel {

    INFO,
    WARNING,
    ERROR,
    CRITICAL,
    FATAL;
}
