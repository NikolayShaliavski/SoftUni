package recycleStation.core;

import recycleStation.contracts.*;
import recycleStation.contracts.Runnable;
import wasteDisposal.contracts.Waste;

import java.io.IOException;


public class Engine implements Runnable {

    private Reader reader;
    private Writer writer;
    private RecycleStation recycleStation;
    private GarbageFactory garbageFactory;

    public Engine(Reader reader,
                  Writer writer,
                  RecycleStation recycleStation,
                  GarbageFactory garbageFactory) {
        this.reader = reader;
        this.writer = writer;
        this.recycleStation = recycleStation;
        this.garbageFactory = garbageFactory;
    }

    @Override
    public void run() throws IOException, ReflectiveOperationException {

        String[] lineParams = this.reader.read().split("[\\s]+");
        String command = lineParams[0];
        while (!command.equals("TimeToRecycle")) {
            switch (command) {
                case "ProcessGarbage":
                    String[] garbageParams = lineParams[1].split("\\|");
                    Waste garbage = this.garbageFactory.createGarbage(garbageParams);
                    String result = this.recycleStation.processWaste(garbage);
                    this.writer.write(result);
                    break;
                case "Status":
                    String stationStatus = this.recycleStation.printStatus();
                    this.writer.write(stationStatus);
                    break;
            }
            lineParams = this.reader.read().split("[\\s+]");
            command = lineParams[0];
        }
    }
}
