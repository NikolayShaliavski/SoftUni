package recycleStation.core;

import recycleStation.contracts.StrategyFactory;
import recycleStation.models.strategies.BurnableStrategy;
import recycleStation.models.strategies.RecycableStrategy;
import recycleStation.models.strategies.StorableStrategy;
import recycleStation.modelsAnnotations.Burnable;
import recycleStation.modelsAnnotations.Recycable;
import recycleStation.modelsAnnotations.Storable;
import wasteDisposal.annotations.Disposable;
import wasteDisposal.contracts.GarbageDisposalStrategy;
import wasteDisposal.contracts.Waste;

import java.lang.annotation.Annotation;
import java.util.HashMap;
import java.util.Map;

public class StrategyFactoryImpl implements StrategyFactory {

    private Map<Class, GarbageDisposalStrategy> availableStrategies;

    public StrategyFactoryImpl() {
        this.initAvailableStrategies();
    }

    @Override
    public GarbageDisposalStrategy createNewStrategy(Waste garbage) throws ReflectiveOperationException {
        GarbageDisposalStrategy newStrategy = null;

        Annotation[] garbageAnots = garbage.getClass().getAnnotations();
        Class garbageAnnotation = null;
        for (Annotation garbageAnot : garbageAnots) {
            if (garbageAnot.annotationType().isAnnotationPresent(Disposable.class)) {
                garbageAnnotation = garbageAnot.annotationType();
                break;
            }
        }

        newStrategy = this.availableStrategies.get(garbageAnnotation);
        return newStrategy;
    }

    private void initAvailableStrategies() {
        this.availableStrategies = new HashMap<>();
        this.availableStrategies.put(Burnable.class, new BurnableStrategy());
        this.availableStrategies.put(Recycable.class, new RecycableStrategy());
        this.availableStrategies.put(Storable.class, new StorableStrategy());
    }
}
