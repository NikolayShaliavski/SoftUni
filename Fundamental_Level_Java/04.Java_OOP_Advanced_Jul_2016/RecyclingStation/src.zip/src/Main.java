import recycleStation.contracts.*;
import recycleStation.contracts.Runnable;
import recycleStation.core.Engine;
import recycleStation.core.GarbageFactoryImpl;
import recycleStation.core.RecycleStationImpl;
import recycleStation.core.StrategyFactoryImpl;
import recycleStation.io.ConsoleReader;
import recycleStation.io.ConsoleWriter;
import wasteDisposal.DefaultGarbageProcessor;
import wasteDisposal.contracts.GarbageProcessor;

import java.io.IOException;

public class Main {

    public static void main(String[] args) throws IOException, ReflectiveOperationException {

        Reader reader = new ConsoleReader();
        Writer writer = new ConsoleWriter();
        GarbageProcessor garbageProcessor = new DefaultGarbageProcessor();
        StrategyFactory strategyFactory = new StrategyFactoryImpl();
        RecycleStation recycleStation = new RecycleStationImpl(garbageProcessor, strategyFactory);
        GarbageFactory garbageFactory = new GarbageFactoryImpl();
        Runnable engine = new Engine(reader, writer, recycleStation, garbageFactory);
        engine.run();
    }
}
