package interfaces;

public interface Attack {

    void execute(Blob source, Blob target);
}
