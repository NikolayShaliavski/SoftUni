package interfaces;

public interface Writer {

    void write(String message);
}
