package problem_08.interfaces;

public interface Private extends Soldier {

    Double getSalary();
}
