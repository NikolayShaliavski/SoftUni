package problem_08.interfaces;

public interface SpecializedSoldier extends Soldier {

    Double getSalary();
    String getCorps();
}
