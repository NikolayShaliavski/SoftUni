package problem_08.interfaces;

public interface Mission {

    String getCodeName();
    String getState();
    void completeMission();
}
