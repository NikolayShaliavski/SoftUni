package problem_08.interfaces;

public interface Repair {

    String getPartName();
    Integer getHours();
}
