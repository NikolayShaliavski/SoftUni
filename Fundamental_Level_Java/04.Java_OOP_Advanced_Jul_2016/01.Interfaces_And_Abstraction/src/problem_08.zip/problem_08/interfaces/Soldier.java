package problem_08.interfaces;

public interface Soldier {

    String getFirstName();
    String getLastName();
    String getId();
}
