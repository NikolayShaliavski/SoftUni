package problem_08.interfaces;

public interface Spy extends Soldier {

    String getCodeNumber();
}
