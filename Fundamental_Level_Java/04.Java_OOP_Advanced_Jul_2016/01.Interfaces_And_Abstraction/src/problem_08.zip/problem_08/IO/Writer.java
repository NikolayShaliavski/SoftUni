package problem_08.IO;

public class Writer {

    public void write(String message) {
        System.out.println(message);
    }
}
