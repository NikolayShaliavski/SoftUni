package problem_08.contracts;

public interface Pet {

    String getName();
    int getAge();
    String getKind();
}
