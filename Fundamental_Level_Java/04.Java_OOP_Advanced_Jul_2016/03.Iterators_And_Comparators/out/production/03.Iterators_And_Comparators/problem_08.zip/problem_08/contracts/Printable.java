package problem_08.contracts;

public interface Printable {

    String print();
    String print(int roomNumber);
}
