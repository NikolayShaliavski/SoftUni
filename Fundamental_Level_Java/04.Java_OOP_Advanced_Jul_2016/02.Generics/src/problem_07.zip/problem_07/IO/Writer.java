package problem_07.IO;

public class Writer {

    public void print(String output) {
        System.out.println(output);
    }

    public void printAll(String output) {
        System.out.print(output);
    }
}
