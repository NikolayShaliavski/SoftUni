package massdefect.app.services;

import massdefect.app.domain.entities.solarSystems.SolarSystem;

public interface SolarSystemService {

    void save(SolarSystem solarSystem);

    SolarSystem findByName(String name);
}