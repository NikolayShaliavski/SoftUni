package massdefect.app.domain.dto;

import java.io.Serializable;

public class PersonImportDto implements Serializable {

    private String name;
    private String homePlanet;

    public PersonImportDto() {
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getHomePlanet() {
        return this.homePlanet;
    }

    public void setHomePlanet(String homePlanet) {
        this.homePlanet = homePlanet;
    }
}
