package massdefect.app.domain.dto;

import java.io.Serializable;

public class AnomalyImportDto implements Serializable {

    private String originPlanet;
    private String teleportPlanet;

    public AnomalyImportDto() {
    }

    public String getOriginPlanet() {
        return this.originPlanet;
    }

    public void setOriginPlanet(String originPlanet) {
        this.originPlanet = originPlanet;
    }

    public String getTeleportPlanet() {
        return this.teleportPlanet;
    }

    public void setTeleportPlanet(String teleportPlanet) {
        this.teleportPlanet = teleportPlanet;
    }
}
