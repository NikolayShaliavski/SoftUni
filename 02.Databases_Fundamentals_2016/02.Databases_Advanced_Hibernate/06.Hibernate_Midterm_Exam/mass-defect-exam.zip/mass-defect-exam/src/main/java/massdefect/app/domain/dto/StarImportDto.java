package massdefect.app.domain.dto;

import java.io.Serializable;

public class StarImportDto implements Serializable {

    private String name;
    private String solarSystem;

    public StarImportDto() {
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSolarSystem() {
        return this.solarSystem;
    }

    public void setSolarSystem(String solarSystem) {
        this.solarSystem = solarSystem;
    }
}
