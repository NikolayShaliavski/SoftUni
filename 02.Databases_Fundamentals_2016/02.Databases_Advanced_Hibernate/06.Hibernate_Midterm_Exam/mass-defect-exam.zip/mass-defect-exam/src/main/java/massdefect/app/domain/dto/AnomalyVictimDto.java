package massdefect.app.domain.dto;

import java.io.Serializable;

public class AnomalyVictimDto implements Serializable {

    private Long id;
    private String person;

    public AnomalyVictimDto() {
    }

    public Long getId() {
        return this.id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getPerson() {
        return this.person;
    }

    public void setPerson(String person) {
        this.person = person;
    }
}
