package massdefect.app.domain.entities.anomaliesCollections;

import massdefect.app.domain.dto.AnomalyWithVictimImportDto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@XmlRootElement(name = "anomalies")
@XmlAccessorType(XmlAccessType.FIELD)
public class AnomalyCollection implements Serializable {

    @XmlElement(name = "anomaly")
    private List<AnomalyWithVictimImportDto> anomalies;

    public AnomalyCollection() {
        this.setAnomalies(new ArrayList<>());
    }

    public List<AnomalyWithVictimImportDto> getAnomalies() {
        return anomalies;
    }

    public void setAnomalies(List<AnomalyWithVictimImportDto> anomalies) {
        this.anomalies = anomalies;
    }
}
