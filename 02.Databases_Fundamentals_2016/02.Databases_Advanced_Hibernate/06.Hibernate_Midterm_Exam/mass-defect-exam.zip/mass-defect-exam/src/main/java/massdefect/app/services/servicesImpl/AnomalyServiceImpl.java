package massdefect.app.services.servicesImpl;

import massdefect.app.domain.entities.anomalies.Anomaly;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import massdefect.app.repositories.AnomalyRepository;
import massdefect.app.services.AnomalyService;

@Service
@Transactional
public class AnomalyServiceImpl implements AnomalyService {

    @Autowired
    private AnomalyRepository anomalyRepository;

    @Override
    public void save(Anomaly anomaly) {
        this.anomalyRepository.saveAndFlush(anomaly);
    }

    @Override
    public Anomaly findById(Long id) {
        return this.anomalyRepository.findOne(id);
    }
}