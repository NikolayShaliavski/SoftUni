package massdefect.app.terminal;

import massdefect.app.dataParsers.jsonParsers.JSONParser;
import massdefect.app.dataParsers.jsonParsers.JSONParserImpl;
import massdefect.app.dataParsers.xmlParsers.XmlParser;
import massdefect.app.dataParsers.xmlParsers.XmlParserImpl;
import massdefect.app.domain.dto.*;
import massdefect.app.domain.entities.anomalies.Anomaly;
import massdefect.app.domain.entities.anomaliesCollections.AnomalyCollection;
import massdefect.app.domain.entities.persons.Person;
import massdefect.app.domain.entities.planets.Planet;
import massdefect.app.domain.entities.solarSystems.SolarSystem;
import massdefect.app.domain.entities.stars.Star;
import massdefect.app.services.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import javax.xml.bind.JAXBException;
import java.util.List;

@Component
public class Terminal implements CommandLineRunner {

    private SolarSystemService solarSystemService;
    private StarService starService;
    private PlanetService planetService;
    private AnomalyService anomalyService;
    private PersonService personService;

    private JSONParser jsonParser;
    private XmlParser xmlParser;

    @Autowired
    public Terminal(SolarSystemService solarSystemService,
                    StarService starService,
                    PlanetService planetService,
                    AnomalyService anomalyService,
                    PersonService personService) {
        this.solarSystemService = solarSystemService;
        this.starService = starService;
        this.planetService = planetService;
        this.anomalyService = anomalyService;
        this.personService = personService;

        this.jsonParser = new JSONParserImpl();
        this.xmlParser = new XmlParserImpl();
    }

    @Override
    public void run(String... strings) throws Exception {
        this.importDataToDatabase();

    }

    private void importDataToDatabase() throws JAXBException {
        this.importSolarSystems();
        this.importStars();
        this.importPlanets();
        this.importPersons();
        this.importAnomalies();
        this.importAnomaliesAndVictims();

        this.importNewAnomalies();
    }

    private void importNewAnomalies() throws JAXBException {
        AnomalyCollection newAnomalies = this.xmlParser.readFromXml(AnomalyCollection.class,
                "src/main/resources/files/input/xml/new-anomalies.xml");

        List<AnomalyWithVictimImportDto> anomalies = newAnomalies.getAnomalies();
        for (AnomalyWithVictimImportDto anomaly : anomalies) {
            try {
                Anomaly newAnomaly = new Anomaly();
                Planet originPlanet = this.findPlanet(anomaly.getOriginPlanet());
                Planet teleportPlanet = this.findPlanet(anomaly.getTeleportPlanet());
                newAnomaly.setOriginPlanet(originPlanet);
                newAnomaly.setTeleportPlanet(teleportPlanet);
                List<VictimImportDto> victims = anomaly.getVictims();
                for (VictimImportDto victim : victims) {
                    Person person = this.personService.findByName(victim.getName());
                    if (person == null) {
                        continue;
                    }
                    newAnomaly.addVictim(person);
                }
                this.anomalyService.save(newAnomaly);
            } catch (IllegalArgumentException ilex) {
                System.out.println(ilex.getMessage());
            }
        }
    }

    private void importAnomaliesAndVictims() {
        AnomalyVictimDto[] anomaliesVictims = this.jsonParser.readFromJSON(AnomalyVictimDto[].class,
                "src/main/resources/files/input/json/anomaly-victims.json");
        for (AnomalyVictimDto anomalyVictim : anomaliesVictims) {
            Long anomalyId = anomalyVictim.getId();
            String personName = anomalyVictim.getPerson();

            Anomaly anomaly = this.anomalyService.findById(anomalyId);
            Person person = this.personService.findByName(personName);

            if (anomaly == null || person == null) {
                continue;
            }
            anomaly.addVictim(person);
            this.personService.save(person);
            this.anomalyService.save(anomaly);
        }
    }

    private void importAnomalies() {
        AnomalyImportDto[] anomalyImportDtos = this.jsonParser.readFromJSON(AnomalyImportDto[].class,
                "src/main/resources/files/input/json/anomalies.json");
        for (AnomalyImportDto anomalyImportDto : anomalyImportDtos) {
            String originPlanetName = anomalyImportDto.getOriginPlanet();
            String teleportPlanetName = anomalyImportDto.getTeleportPlanet();
            try {
                Planet originPlanet = this.findPlanet(originPlanetName);
                Planet teleportPlanet = this.findPlanet(teleportPlanetName);
                Anomaly anomaly = new Anomaly();
                anomaly.setOriginPlanet(originPlanet);
                anomaly.setTeleportPlanet(teleportPlanet);
                this.anomalyService.save(anomaly);
                System.out.println("Successfully imported anomaly.");
            } catch (IllegalArgumentException ilex) {
                System.out.println(ilex.getMessage());
            }
        }
    }

    private void importPersons() {
        PersonImportDto[] personImportDtos = this.jsonParser.readFromJSON(PersonImportDto[].class,
                "src/main/resources/files/input/json/persons.json");
        for (PersonImportDto personImportDto : personImportDtos) {
            String personName = personImportDto.getName();
            String homePlanetName = personImportDto.getHomePlanet();
            try {
                Planet homePlanet = this.findPlanet(homePlanetName);
                Person person = new Person();
                person.setName(personName);
                person.setHomePlanet(homePlanet);
                this.personService.save(person);
                System.out.println(
                        String.format("Successfully imported Person %s.",
                                person.getName()));
            } catch (IllegalArgumentException ilex) {
                System.out.println(ilex.getMessage());
            }
        }
    }

    private void importPlanets() {
        PlanetImportDto[] planetImportDtos = this.jsonParser.readFromJSON(PlanetImportDto[].class,
                "src/main/resources/files/input/json/planets.json");
        for (PlanetImportDto planetImportDto : planetImportDtos) {
            String planetName = planetImportDto.getName();
            String sunName = planetImportDto.getSun();
            String solarSystemName = planetImportDto.getSolarSystem();
            try {
                Star sun = this.findStar(sunName);
                SolarSystem solarSystem = this.findSolarSystem(solarSystemName);
                Planet planet = new Planet();
                planet.setName(planetName);
                planet.setSun(sun);
                planet.setSolarSystem(solarSystem);
                this.planetService.save(planet);
                System.out.println(
                        String.format("Successfully imported Planet %s.",
                                planet.getName()));
            } catch (IllegalArgumentException ilex) {
                System.out.println(ilex.getMessage());
            }
        }
    }

    private void importStars() {
        StarImportDto[] starImportDtos = this.jsonParser.readFromJSON(StarImportDto[].class,
                "src/main/resources/files/input/json/stars.json");
        for (StarImportDto starImportDto : starImportDtos) {
            String starName = starImportDto.getName();
            String solarSystemName = starImportDto.getSolarSystem();
            try {
                SolarSystem solarSystem = this.findSolarSystem(solarSystemName);
                Star star = new Star();
                star.setName(starName);
                star.setSolarSystem(solarSystem);
                this.starService.save(star);
                System.out.println(
                        String.format("Successfully imported Star %s.",
                                star.getName()));
            } catch (IllegalArgumentException ilex) {
                System.out.println(ilex.getMessage());
            }
        }
    }

    private void importSolarSystems() {
        SolarSystemImportDto[] solarSystemDtos =
                this.jsonParser.readFromJSON(SolarSystemImportDto[].class,
                        "src/main/resources/files/input/json/solar-systems.json");
        for (SolarSystemImportDto solarSystemDto : solarSystemDtos) {
            SolarSystem solarSystem = new SolarSystem();
            try {
                solarSystem.setName(solarSystemDto.getName());
                this.solarSystemService.save(solarSystem);
                System.out.println(
                        String.format("Successfully imported Solar System %s.",
                                solarSystem.getName()));
            } catch (IllegalArgumentException ilex) {
                System.out.println(ilex.getMessage());
            }
        }
    }

    private SolarSystem findSolarSystem(String solarSystemName) {
        return this.solarSystemService.findByName(solarSystemName);
    }

    private Star findStar(String starName) {
        return this.starService.findByName(starName);
    }

    private Planet findPlanet(String planetName) {
        return this.planetService.findByName(planetName);
    }
}
