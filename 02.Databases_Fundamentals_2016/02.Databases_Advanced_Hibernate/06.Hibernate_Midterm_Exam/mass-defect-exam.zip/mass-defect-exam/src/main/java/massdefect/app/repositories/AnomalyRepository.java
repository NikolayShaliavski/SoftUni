package massdefect.app.repositories;

import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.JpaRepository;
import massdefect.app.domain.entities.anomalies.Anomaly;

@Repository
public interface AnomalyRepository extends JpaRepository<Anomaly,Long> {
}