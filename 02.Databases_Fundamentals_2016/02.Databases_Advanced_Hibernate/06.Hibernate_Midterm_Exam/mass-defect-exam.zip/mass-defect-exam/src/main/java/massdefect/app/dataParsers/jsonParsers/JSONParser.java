package massdefect.app.dataParsers.jsonParsers;

public interface JSONParser {

    <T> T[] readFromJSON(Class<T[]> classes, String file);
}
