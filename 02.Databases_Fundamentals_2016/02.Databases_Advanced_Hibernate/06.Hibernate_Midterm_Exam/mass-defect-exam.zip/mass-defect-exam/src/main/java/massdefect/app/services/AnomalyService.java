package massdefect.app.services;

import massdefect.app.domain.entities.anomalies.Anomaly;

public interface AnomalyService {

    void save(Anomaly anomaly);

    Anomaly findById(Long id);
}