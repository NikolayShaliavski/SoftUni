package massdefect.app.repositories;

import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.JpaRepository;
import massdefect.app.domain.entities.persons.Person;

@Repository
public interface PersonRepository extends JpaRepository<Person,Long> {

    Person findByName(String name);
}