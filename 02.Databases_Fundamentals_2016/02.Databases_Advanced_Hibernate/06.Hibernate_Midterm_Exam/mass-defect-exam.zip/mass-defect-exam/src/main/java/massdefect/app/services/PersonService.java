package massdefect.app.services;

import massdefect.app.domain.entities.persons.Person;

public interface PersonService {

    void save(Person person);

    Person findByName(String name);
}