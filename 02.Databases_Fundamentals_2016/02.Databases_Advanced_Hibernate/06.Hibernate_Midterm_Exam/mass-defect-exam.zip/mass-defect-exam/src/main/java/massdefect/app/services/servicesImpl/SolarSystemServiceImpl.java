package massdefect.app.services.servicesImpl;

import massdefect.app.domain.entities.solarSystems.SolarSystem;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import massdefect.app.repositories.SolarSystemRepository;
import massdefect.app.services.SolarSystemService;

@Service
@Transactional
public class SolarSystemServiceImpl implements SolarSystemService {

    @Autowired
    private SolarSystemRepository solarSystemRepository;

    @Override
    public void save(SolarSystem solarSystem) {
        this.solarSystemRepository.saveAndFlush(solarSystem);
    }

    @Override
    public SolarSystem findByName(String name) {
        return this.solarSystemRepository.findByName(name);
    }
}