package massdefect.app.services;

import massdefect.app.domain.entities.planets.Planet;

public interface PlanetService {

    void save(Planet planet);

    Planet findByName(String name);
}