package massdefect.app.services.servicesImpl;

import massdefect.app.domain.entities.stars.Star;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import massdefect.app.repositories.StarRepository;
import massdefect.app.services.StarService;

@Service
@Transactional
public class StarServiceImpl implements StarService {

    @Autowired
    private StarRepository starRepository;

    @Override
    public void save(Star star) {
        this.starRepository.saveAndFlush(star);
    }

    @Override
    public Star findByName(String name) {
        return this.starRepository.findByName(name);
    }
}