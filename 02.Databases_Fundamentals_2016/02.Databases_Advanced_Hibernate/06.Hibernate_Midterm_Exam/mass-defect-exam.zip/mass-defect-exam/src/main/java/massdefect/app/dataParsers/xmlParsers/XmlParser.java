package massdefect.app.dataParsers.xmlParsers;

import javax.xml.bind.JAXBException;

public interface XmlParser {

    <T> T readFromXml(Class<T> classes, String fileName) throws JAXBException;
}
