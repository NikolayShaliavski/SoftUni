package massdefect.app.repositories;

import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.JpaRepository;
import massdefect.app.domain.entities.planets.Planet;

@Repository
public interface PlanetRepository extends JpaRepository<Planet,Long> {

    Planet findByName(String name);
}