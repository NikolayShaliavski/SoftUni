package massdefect.app.services;

import massdefect.app.domain.entities.stars.Star;

public interface StarService {

    void save(Star star);

    Star findByName(String name);
}