package massdefect.app.services.servicesImpl;

import massdefect.app.domain.entities.planets.Planet;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import massdefect.app.repositories.PlanetRepository;
import massdefect.app.services.PlanetService;

@Service
@Transactional
public class PlanetServiceImpl implements PlanetService {

    @Autowired
    private PlanetRepository planetRepository;

    @Override
    public void save(Planet planet) {
        this.planetRepository.saveAndFlush(planet);
    }

    @Override
    public Planet findByName(String name) {
        return this.planetRepository.findByName(name);
    }
}