package photography;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PhotographyWorkshopsExamApplication {

	public static void main(String[] args) {
		//RepositoryServiceBuilder.build();
		SpringApplication.run(PhotographyWorkshopsExamApplication.class, args);
	}
}
