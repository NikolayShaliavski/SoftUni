package users.database.problem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserDatabaseApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserDatabaseApplication.class, args);
	}
}
